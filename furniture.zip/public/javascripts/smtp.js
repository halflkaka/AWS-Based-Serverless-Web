function send() {
    $(document).ready(function(){
        var from,to,subject,text;
        $("#send_email").click(function(){      
            // to=$("#to").val();      
            // $("#message").text("Sending E-mail...Please wait");
            // $.get("http://localhost:3000/users/send",{to:to},function(data){
            //     if(data=="sent")
            //     {
            //         $("#message").empty().html("<p>Email is been sent at "+to+" . Please check inbox !</p >");
            //     }
            // });
            console.log("click");
            to=$("#to").val();  
            $.ajax({
                type: "POST",
                url: "http://furniture-dev.us-east-1.elasticbeanstalk.com/users/register",
                data: {"email": "1@yahoo.com", "user": "1", "password": "1"},
                dataType: "json",
                success: function(data, status){
                    console.log("Info has been sent to beanstalk!");
                },
                error: function(e){
                    console.log("error!");
                }
            });
            // var settings = {
            //     "async": true,
            //     "crossDomain": true,
            //     "url": "http://furniture-dev.us-east-1.elasticbeanstalk.com/users/register",
            //     "method": "POST",
            //     "headers": {
            //       "Content-Type": "application/json",
            //       "cache-control": "no-cache",
            //       "Postman-Token": "7cf05520-c76a-4f2a-948d-597449bb711c"
            //     },
            //     "processData": false,
            //     "data": "{\n\t\"email\": \"cs@columbia.edu\",\n\t\"name\": \"test\",\n\t\"password\": \"123\"\n}"
            //   }
              
            //   $.ajax(settings).done(function (response) {
                
            //     console.log(response);
            //   });
        });
    });
}

send();