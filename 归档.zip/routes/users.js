var express = require('express');
var router = express.Router();
// var userModel = require('../models/userModel');
var UserAuth = require('../utils/UserAuth');

/* GET users listing. */
router.get('/', function(req, res, next) {
  var db = req.con;
  db.query('SELECT * FROM users ', function(err, rows) {
    if (err) {  
        console.log(err);
    }
    res.send(rows);
  });
});

router.post('/login', UserAuth.login);

router.post('/register', UserAuth.registration);


router.post('/authenticate', UserAuth.authentication);

router.post('/tokensignin', function(req, res, next) {
  console.log(req.body);
})


// router.get('/send', UserAuth.sendEmail);

// router.get('/verify', UserAuth.verifyEmail);

// router.get('/logout', UserAuth.logOut);

module.exports = router;
